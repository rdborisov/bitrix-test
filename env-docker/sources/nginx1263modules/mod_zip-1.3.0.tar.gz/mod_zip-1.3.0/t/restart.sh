#!/bin/bash

pkill nginx
./nginx/sbin/nginx
