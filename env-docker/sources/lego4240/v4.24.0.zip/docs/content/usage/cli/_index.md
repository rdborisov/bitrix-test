---
title: "CLI"
date: 2019-03-03T16:39:46+01:00
draft: false
---

Lego can be use as a CLI.

<!--more-->

{{% children style="h2" description="true" %}}
